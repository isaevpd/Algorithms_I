import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.Collections;


public class Brute 
{
   public static void main(String[] args)
   {
        In input = new In(args[0]);

        int[] rawData = input.readAllInts();

        Point[] data = new Point[(rawData.length - 1) / 2];

        int next = 0;

        Point[] temp;
        // Object[] dr = new Object[2];

        Set<HashSet> drawings = new HashSet<HashSet>();

        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);

        for (int i = 1; i < rawData.length; i += 2)
        {
            data[next] = new Point(rawData[i], rawData[i + 1]);
            data[next].draw();
            // for (Point p : data) StdOut.println(p);
            next++;
        }
        for (Point p : data)
        {
            for (Point q: data)
            {
                if (p == q) break;
                for (Point r: data)
                {
                    if (q == r) break;
                    for (Point s:data)
                    {
                        if (r == s) break;
                        if (q == s) break;
                        if (p == r) break;
                        if (p.slopeTo(q) == p.slopeTo(r) & p.slopeTo(r) == p.slopeTo(s))
                            {
                                temp = new Point[]{p, q, r, s};
                                Arrays.sort(temp);
                                temp[0].drawTo(temp[3]);
                                for (int i = 0; i < temp.length; i++)
                                {
                                    // if (!drawings.contains(new HashSet<Point>(Arrays.asList(temp[0], temp[3])))) { temp[0].drawTo(temp[3]); 
                                                                                                                // drawings.add(new HashSet<Point>(Arrays.asList(temp[0], temp[3]))); }

                                    if (i != temp.length - 1) StdOut.print(temp[i] + " -> ");
                                    else StdOut.println(temp[i]);
                                    // for (Object points : drawings) StdOut.print(points);
                                    // StdOut.println();
                                }                      
                            }

                         //StdOut.print(p + " -> "); StdOut.print(q + " -> "); StdOut.print(r + " -> "); StdOut.print(s); StdOut.println();}
                    }
                }
            }
        }
        // for (Set set: drawings)
        // {
        //     next = 0;
        //     for (Object p : set) dr[next++] = new Point(p);
        //     for (Point p : dr) StdOut.print(p);
        //     StdOut.println();
            

        // }    
            
   }
}