public class Fast 
{
   public static void main(String[] args)
   {
    
   }
}